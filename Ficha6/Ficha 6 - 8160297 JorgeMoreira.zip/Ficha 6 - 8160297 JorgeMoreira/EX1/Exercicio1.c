/* 
 * File:   Exercicio1.c
 * Author: Jorge Moreira
 * Ficha6
 * Created on 18 de Novembro de 2017, 14:44
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Utils.h"


int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

