/* 
 * File:   Utils.h
 * Author: Jorge Moreira
 * Ficha6
 * Created on 18 de Novembro de 2017, 14:48
 */

#ifndef UTILS_H
#define UTILS_H

void clean_buffer();
int lerString(char *string, int max);

#endif /* UTILS_H */

