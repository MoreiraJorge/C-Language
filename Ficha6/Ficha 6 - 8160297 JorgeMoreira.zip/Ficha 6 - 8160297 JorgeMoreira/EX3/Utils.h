/* 
 * File:   Utils.h
 * Author: Jorge Moreira
 * Ficha6 - Exercicio3
 * Created on 18 de Novembro de 2017, 15:11
 */

#ifndef UTILS_H
#define UTILS_H

void clean_buffer();
int lerString(char *string, int max);

#endif /* UTILS_H */

