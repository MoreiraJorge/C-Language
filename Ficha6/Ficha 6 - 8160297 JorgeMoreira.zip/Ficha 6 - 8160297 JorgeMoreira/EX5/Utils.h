/* 
 * File:   Utils.h
 * Author: Jorge Moreira
 * Ficha 6 - Exercicio 5
 * Created on 21 de Novembro de 2017, 15:55
 */

#ifndef UTILS_H
#define UTILS_H

void clean_buffer();
int lerString(char *string, int max);

#endif /* UTILS_H */

