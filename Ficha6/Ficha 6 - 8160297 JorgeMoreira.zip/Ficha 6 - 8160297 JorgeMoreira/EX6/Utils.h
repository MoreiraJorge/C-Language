/* 
 * File:   Utils.h
 * Author: Jorge Moreira
 * Ficha 6 - Exercicio 6
 * Created on 21 de Novembro de 2017, 16:07
 */

#ifndef UTILS_H
#define UTILS_H

void clean_buffer();
int lerString(char *string, int max);
void countChar(char frase1[], char caracter);

#endif /* UTILS_H */

