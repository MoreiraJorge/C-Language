/* 
 * File:   Utils.h
 * Author: Jorge Moreira
 * Ficha6 - Exercicio7
 * Created on 22 de Novembro de 2017, 18:01
 */

#ifndef UTILS_H
#define UTILS_H

void clean_buffer();
int lerString(char *string, int max);

#endif /* UTILS_H */

