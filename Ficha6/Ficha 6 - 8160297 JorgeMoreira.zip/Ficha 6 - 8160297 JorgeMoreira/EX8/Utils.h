/* 
 * File:   Utils.h
 * Author: Jorge Moreira
 * Ficha6 - Exercicio 8
 * Created on 23 de Novembro de 2017, 10:27
 */

#ifndef UTILS_H
#define UTILS_H

void clean_buffer();
int lerString(char *string, int max);
int lastindex(char caracter, char frase[], int fimfrase);

#endif /* UTILS_H */

