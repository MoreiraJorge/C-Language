/* 
 * File:   Utils.h
 * Author: Jorge Moreira
 * ficha7 - exercicio 3
 * Created on 23 de Novembro de 2017, 14:24
 */

#ifndef UTILS_H
#define UTILS_H

#define LINHAS 4
#define COLUNAS 3

void printmatriz(int matriz[][COLUNAS]);
void pedirmatriz(int matriz[][COLUNAS]);

#endif /* UTILS_H */

