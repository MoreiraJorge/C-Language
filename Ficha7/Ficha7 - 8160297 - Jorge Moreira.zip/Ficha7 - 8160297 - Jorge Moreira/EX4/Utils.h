/* 
 * File:   Utils.h
 * Author: Jorge Moreira
 * ficha7 - exercicio4
 * Created on 24 de Novembro de 2017, 14:37
 */

#define LINHAS 3
#define COLUNAS 3

#ifndef UTILS_H
#define UTILS_H

void pedirmatriz(int matriz[][COLUNAS]);
void printmatriz(int matriz[][COLUNAS]);
void printmatrizB(int matrizA[][COLUNAS]);


#endif /* UTILS_H */

