/* 
 * File:   Utils.h
 * Author: Jorge Moreira
 * Ficha 7 - Exercicio 5
 * Created on 24 de Novembro de 2017, 16:02
 */

#ifndef UTILS_H
#define UTILS_H

#define MAX 3

void FillMatrix(int matrix[][MAX]);
void writeMatrix(int matrix[][MAX]);
void printreversedmatrix(int matrix[][MAX]);

#endif /* UTILS_H */

