/* 
 * File:   utils.h
 * Author: Jorge Moreira
 * Trabalho1 - Versao2
 * Created on 1 de Dezembro de 2017, 15:51
 */

#ifndef UTILS_H
#define UTILS_H

void clean_buffer();

#endif /* UTILS_H */

